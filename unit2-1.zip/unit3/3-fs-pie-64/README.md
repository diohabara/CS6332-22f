PIE, NX, Stack-cookie enabled can use still exploit this?

Use SR, AR and AW wisely to 
    1. Leak binary program!
    2. Understand what program does!
    3. Get a shell!
    Then, read the flag!

`nc 10.176.150.33 60051` to find the flag.
