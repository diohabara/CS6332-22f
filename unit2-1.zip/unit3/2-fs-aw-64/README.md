now it is time to take a control over a  variable somwehre in memory. craft your input to overwrite and pass the check.

