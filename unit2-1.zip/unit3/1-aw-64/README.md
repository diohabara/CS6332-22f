again ret2libc. let's call a function from libc to run a command.
the program took care of setreguid() for you.

